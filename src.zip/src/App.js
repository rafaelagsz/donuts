// import Detalhes from "./page/Detalhes/Detalhes";
import Home from "./page/Home/Home";
import { useState } from "react";
import StyledGlobal, {CorFundo} from "./styledGlobal";

function App() {
  const [trocarDePagina, setTrocarDePagina] = useState("0")

  const changePage = (change) => {
    setTrocarDePagina(change)
  }

  return (
    <>
    <CorFundo>
      <StyledGlobal/>
      {trocarPagina === "0" ? (
        <Home pagina={()=> changePage("0")}/>
      ) : (
        <Detalhes pagina={()=> changePage("1")}/>
      )}


    </CorFundo>
    </>
  );
}

export default App;
