import { DetalhesTitulo, TituloHeaderContainer } from "./styles"

function TituloHeader(){
    return(
        <TituloHeader> Some sweets of
            <DetalhesTitulo> Happiness! </DetalhesTitulo>
        </TituloHeader>
    )
}

export default TituloHeader