import Header from "../../components/Header/Header"
import seta from "../../assets/seta.png"
import ponto from "../../assets/ponto.png"
import group from "../../assets/group.png"
import DonutGrande from "../../assets/Frame 9.png"
import { BotaoAddCard, BotaoMore, ContainerDetalhes, ContainerDiv, ImagemGrande, MaisProdutos, TextMore, TextNumber, TextoDonuts, TituloDonuts } from "./styles"

function Detalhes(props){
    return(
        <>
            <Header 
            pagina={props.pagina} 
            imgPrimeira={seta}
            imgSegunda={ponto}
            />

            <ContainerDetalhes>
                <ImagemGrande src={DonutGrande}/>

                <ContainerDiv>
                    <TituloDonuts>
                        Unicorn Sprinkles
                    </TituloDonuts>
                    <TextoDonuts>
                        A fluffy fresh cooked donut covered
                        by a creamy strawberry flavour with
                        rainbow sprinkles.
                    </TextoDonuts>

                    <MaisProdutos>
                        <img src={group} />
                        <TextNumber>7800</TextNumber>
                    </MaisProdutos>

                    <MaisProdutos>
                        <TextMore>Need more?</TextMore>
                        <BotaoMore>Add more</BotaoMore>
                    </MaisProdutos>

                    <BotaoAddCard>Add to cart</BotaoAddCard>
                </ContainerDiv>
            </ContainerDetalhes>
        </>
    )
}

export default Detalhes